import sys, torch
from transformers import AutoTokenizer, AutoModelForCausalLM
MODEL_DIR = sys.argv[1] if len(sys.argv) > 1 else "./runtime/llama32-1b-a"
tok = AutoTokenizer.from_pretrained("meta-llama/Llama-3.2-1B")
model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, torch_dtype=torch.bfloat16, device_map="cuda").eval()
print("جاهز. اكتب بداية جملة (exit للخروج).")
while True:
    p = input("\n>>> ").strip()
    if p.lower() in ("exit", "quit", "q"): break
    if not p: continue
    x = tok(p, return_tensors="pt").to("cuda")
    with torch.no_grad():
        o = model.generate(**x, max_new_tokens=80, do_sample=False,
                           repetition_penalty=1.2, pad_token_id=tok.eos_token_id)
    print(tok.decode(o[0], skip_special_tokens=True, clean_up_tokenization_spaces=False))
